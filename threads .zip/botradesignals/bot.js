const { Client, GatewayIntentBits, EmbedBuilder, ActivityType, ChannelType, ThreadAutoArchiveDuration } = require("discord.js");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const axios = require("axios");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

const CONFIG = {
  ALLOWED_CHANNELS: process.env.ALLOWED_CHANNELS
    ? process.env.ALLOWED_CHANNELS.split(",").map((c) => c.trim())
    : [],
  PREMIUM_ROLE: process.env.PREMIUM_ROLE || "",
  COOLDOWN_SECONDS: 30,
};

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

// Queue system
let queueRunning = false;
const requestQueue = [];

async function enqueue(fn) {
  return new Promise((resolve, reject) => {
    requestQueue.push({ fn, resolve, reject });
    processQueue();
  });
}

async function processQueue() {
  if (queueRunning || requestQueue.length === 0) return;
  queueRunning = true;
  const { fn, resolve, reject } = requestQueue.shift();
  try {
    const result = await fn();
    resolve(result);
  } catch (err) {
    reject(err);
  } finally {
    await sleep(4000);
    queueRunning = false;
    processQueue();
  }
}

// Per user cooldowns
const cooldowns = new Map();

function hasPermission(message) {
  if (CONFIG.ALLOWED_CHANNELS.length > 0 && !CONFIG.ALLOWED_CHANNELS.includes(message.channel.id)) return false;
  if (CONFIG.PREMIUM_ROLE) {
    const hasRole = message.member?.roles.cache.some((r) => r.name === CONFIG.PREMIUM_ROLE);
    if (!hasRole) return false;
  }
  return true;
}

function getCooldownRemaining(userId) {
  if (!cooldowns.has(userId)) return 0;
  const elapsed = (Date.now() - cooldowns.get(userId)) / 1000;
  const remaining = CONFIG.COOLDOWN_SECONDS - elapsed;
  return remaining > 0 ? Math.ceil(remaining) : 0;
}

async function downloadImageAsBase64(url) {
  const response = await axios.get(url, { responseType: "arraybuffer" });
  const base64 = Buffer.from(response.data).toString("base64");
  const mimeType = response.headers["content-type"] || "image/png";
  return { base64, mimeType };
}

async function analyseChart(base64Image, mimeType, pair, tf) {
  const prompt = `You are an elite professional trading analyst specialising in technical analysis.
Analyse this ${pair} ${tf} chart screenshot carefully.
Look at the price action, trends, support/resistance levels, any indicators visible, candlestick patterns, and momentum.
Base ALL price levels on the actual numbers you can see on the chart axes.

Respond with ONLY a valid JSON object, no markdown, no backticks, no explanation:
{
  "pair": "${pair}",
  "tf": "${tf}",
  "direction": "BUY or SELL",
  "entry": "exact price from chart",
  "sl": "stop loss price",
  "tp": "take profit price",
  "rr": "risk reward e.g. 1:2.5",
  "trend": "BULLISH or BEARISH or RANGING",
  "bias": "one sentence on market bias",
  "setup": "the pattern or setup you see e.g. Order Block, FVG, Engulfing, Support Bounce",
  "keyLevels": "key support and resistance levels you identified from the chart",
  "analysis": "3-4 sentence detailed technical analysis of what you see on this specific chart"
}`;

  const result = await model.generateContent([
    { text: prompt },
    { inlineData: { data: base64Image, mimeType } },
  ]);

  const text = result.response.text().trim();
  const clean = text.replace(/```json\s*/gi, "").replace(/```\s*/g, "").trim();
  const match = clean.match(/\{[\s\S]+\}/);
  if (!match) throw new Error("No JSON in response");

  const parsed = JSON.parse(match[0]);
  if (!parsed.direction || !parsed.entry) throw new Error("Incomplete signal");
  return parsed;
}

// Live cooldown timer
async function sendCooldownTimer(channel, userId, seconds) {
  const total = seconds;
  const makeBar = (remaining) => {
    const filled = Math.round(((total - remaining) / total) * 10);
    return "🟨".repeat(filled) + "⬛".repeat(10 - filled);
  };
  const makeEmbed = (remaining) =>
    new EmbedBuilder()
      .setColor(0xf59e0b)
      .setTitle("⏳ Cooldown Active")
      .setDescription(
        `<@${userId}> please wait before submitting another chart.\n\n` +
        `${makeBar(remaining)}  **${remaining}s remaining**`
      )
      .setFooter({ text: "Botradesignals • Cooldown" });

  const msg = await channel.send({ embeds: [makeEmbed(seconds)] }).catch(() => null);
  if (!msg) return;

  const interval = setInterval(async () => {
    seconds--;
    if (seconds <= 0) {
      clearInterval(interval);
      await msg.edit({
        embeds: [
          new EmbedBuilder()
            .setColor(0x16a34a)
            .setTitle("✅ Ready!")
            .setDescription(`<@${userId}> you can now submit another chart.`)
            .setFooter({ text: "Botradesignals" }),
        ],
      }).catch(() => {});
      setTimeout(() => msg.delete().catch(() => {}), 5000);
      return;
    }
    await msg.edit({ embeds: [makeEmbed(seconds)] }).catch(() => clearInterval(interval));
  }, 1000);
}

function buildSignalEmbed(sig, username, avatarURL) {
  const isBuy = sig.direction === "BUY";
  const colour = isBuy ? 0x16a34a : 0xdc2626;
  const trendEmoji = sig.trend === "BULLISH" ? "📈" : sig.trend === "BEARISH" ? "📉" : "↔️";

  return new EmbedBuilder()
    .setColor(colour)
    .setTitle(`${isBuy ? "🟢" : "🔴"}  ${sig.pair}  —  ${sig.direction}  SIGNAL`)
    .setDescription(`**Timeframe:** ${sig.tf}  •  **Trend:** ${trendEmoji} ${sig.trend}`)
    .addFields(
      { name: "📍 Entry",        value: `\`${sig.entry}\``, inline: true },
      { name: "🛡 Stop Loss",    value: `\`${sig.sl}\``,    inline: true },
      { name: "🎯 Take Profit",  value: `\`${sig.tp}\``,    inline: true },
      { name: "⚖️ Risk/Reward",  value: `\`${sig.rr}\``,   inline: true },
      { name: "💡 Setup",        value: sig.setup,          inline: true },
      { name: "📐 Bias",         value: sig.bias,           inline: false },
      { name: "🔑 Key Levels",   value: sig.keyLevels,      inline: false },
      { name: "🤖 AI Analysis",  value: sig.analysis,       inline: false },
      { name: "⚠️ Risk Warning", value: "*Educational only. Always use proper risk management. Max 1-2% per trade.*", inline: false }
    )
    .setFooter({ text: `Botradesignals • Chart by ${username}`, iconURL: avatarURL })
    .setTimestamp();
}

function buildErrorEmbed(msg) {
  return new EmbedBuilder()
    .setColor(0x7f1d1d)
    .setTitle("⚠️ Analysis Failed")
    .setDescription(msg)
    .setFooter({ text: "Botradesignals" })
    .setTimestamp();
}

function buildHelpEmbed() {
  return new EmbedBuilder()
    .setColor(0xfacc15)
    .setTitle("📊 Botradesignals — How To Use")
    .setDescription("Upload a chart screenshot with the pair and timeframe in your message.")
    .addFields(
      {
        name: "📸 Example",
        value: "Type `XAUUSD H1` and attach your TradingView/MT4/MT5 screenshot.\n\nOther examples:\n`EURUSD M15` + screenshot\n`BTCUSD D1` + screenshot",
      },
      { name: "⌨️ Commands", value: "`!help` — show this\n`!ping` — check bot is online" },
      { name: "⏳ Cooldown", value: `Each user has a ${CONFIG.COOLDOWN_SECONDS}s cooldown between submissions.` },
      { name: "⚠️ Disclaimer", value: "For educational purposes only. Always use proper risk management." }
    )
    .setFooter({ text: "Botradesignals • Powered by Google Gemini (Free)" })
    .setTimestamp();
}

// ── Bot Events ───────────────────────────────────────────────────────────────

client.once("ready", () => {
  console.log(`✅ Botradesignals online — ${client.user.tag}`);
  client.user.setActivity("charts 📊", { type: ActivityType.Watching });
});

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const content = message.content.trim();

  if (content === "!ping") return message.reply("🟢 Online! Upload a chart to get a signal.");
  if (content === "!help" || content === "!signal") return message.reply({ embeds: [buildHelpEmbed()] });

  const attachments = [...message.attachments.values()];
  const imageAttachment = attachments.find((a) => a.contentType?.startsWith("image/"));
  if (!imageAttachment) return;

  if (!hasPermission(message)) {
    if (CONFIG.PREMIUM_ROLE) {
      return message.reply({
        embeds: [buildErrorEmbed(`🔒 You need the **${CONFIG.PREMIUM_ROLE}** role to use Botradesignals.`)],
      });
    }
    return;
  }

  // Cooldown check
  const remaining = getCooldownRemaining(message.author.id);
  if (remaining > 0) {
    await sendCooldownTimer(message.channel, message.author.id, remaining);
    return;
  }
  cooldowns.set(message.author.id, Date.now());

  const upper = content.toUpperCase();
  const pairMatch = upper.match(/\b(XAUUSD|EURUSD|GBPUSD|USDJPY|BTCUSD|ETHUSD|USOIL|US30|NAS100|[A-Z]{6})\b/);
  const tfMatch   = upper.match(/\b(M1|M5|M15|M30|H1|H2|H4|H8|D1|W1)\b/);

  const pair = pairMatch ? pairMatch[0] : "UNKNOWN";
  const tf   = tfMatch   ? tfMatch[0]   : "UNKNOWN";

  await message.react("🔍").catch(() => {});

  // Create a PRIVATE thread — only the user and admins can see it
  let thread = null;
  try {
    thread = await message.channel.threads.create({
      name: `📊 ${message.author.username} — ${pair} ${tf}`,
      autoArchiveDuration: ThreadAutoArchiveDuration.OneHour,
      type: ChannelType.PrivateThread,
      invitable: false, // only admins can add others
      reason: "Private chart analysis thread",
    });

    // Add only the requesting user to the thread
    await thread.members.add(message.author.id);
    await thread.send(`⏳ <@${message.author.id}> Analysing your chart... please wait.`);
  } catch (err) {
    console.error("Thread creation failed:", err.message);
    thread = null;
  }

  const waitMsg = !thread
    ? await message.channel.send("⏳ Analysing your chart...").catch(() => null)
    : null;

  try {
    const { base64, mimeType } = await downloadImageAsBase64(imageAttachment.url);
    const signal = await enqueue(() => analyseChart(base64, mimeType, pair, tf));

    const embed = buildSignalEmbed(signal, message.author.username, message.author.displayAvatarURL());

    if (thread) {
      // Delete the waiting message
      const msgs = await thread.messages.fetch({ limit: 5 });
      msgs.forEach(m => { if (m.author.bot) m.delete().catch(() => {}); });
      await thread.send({ content: `<@${message.author.id}> here is your signal:`, embeds: [embed] });
    } else {
      await waitMsg?.delete().catch(() => {});
      await message.reply({ embeds: [embed] });
    }

    await message.reactions.cache.get("🔍")?.remove().catch(() => {});
    await message.react("✅").catch(() => {});

  } catch (err) {
    console.error("Error:", err.message);

    let userMsg = "Analysis failed. Please try again with a clearer chart screenshot.";
    if (err.message?.includes("No JSON") || err.message?.includes("Incomplete")) {
      userMsg = "Could not read the chart. Make sure your screenshot shows a clear price chart with the price axis visible.";
    } else if (err.message?.includes("401") || err.message?.includes("API_KEY")) {
      userMsg = "API key error — please contact the server admin.";
    } else if (err.message?.includes("429") || err.message?.includes("quota")) {
      userMsg = "Google API rate limit reached. Please wait 1-2 minutes and try again.";
    }

    const errorEmbed = buildErrorEmbed(userMsg);
    if (thread) {
      await thread.send({ embeds: [errorEmbed] });
    } else {
      await waitMsg?.delete().catch(() => {});
      await message.reply({ embeds: [errorEmbed] });
    }

    await message.reactions.cache.get("🔍")?.remove().catch(() => {});
    await message.react("❌").catch(() => {});
  }
});

client.login(process.env.DISCORD_TOKEN);
